<?php if(homey_option('site_breadcrumb')) {
	homey_breadcrumbs();
} ?>