export const SERVER_IP = 'http://localhost:3000'  // local IP
// SERVER_IP = 'https://argo-heroku.herokuapp.com'  // Heroku IP